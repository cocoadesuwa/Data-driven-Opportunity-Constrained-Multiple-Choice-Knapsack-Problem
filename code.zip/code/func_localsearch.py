import re
import time
import heapq
import random
import numpy as np
from random import choice
from solution_operation import solution_initialization, solution_evaluation, solution_cost

# 构建初始可行解的过程
def Construct_Procedure(Fw, Fu, item2obj, CL, Tmax, param, la, ra):
    Eval_times = 0
    # 根据给定规则初始化一个解
    Solution = solution_initialization(Fu, param, 0)
    _St = np.copy(Solution)
    available_S = np.copy(Solution)
    # 评估初始解的质量
    _pt = solution_evaluation(_St, item2obj, Tmax, CL, _lambda=la, risk_averse=ra)
    stopping_condition = -np.ones(len(available_S), int)
    select_factor = -1
    Eval_times += 1
    while True:
        item_list = []
        for item_id in _St:
            item_list.append(item2obj[item_id])
        solution_weight = [item.weight for item in item_list]
        for i in range(len(available_S)):
            if available_S[i] == -1:
                solution_weight[i] = -1
        # 选择重量最大的因子
        select_factor = np.argsort(solution_weight)[-1]
        select_item = _St[select_factor]
        # 如果该因子还有可替换的物品，则尝试替换
        if Fw[select_factor].index(select_item) < len(Fw[select_factor]) - 1:
            _St[select_factor] = Fw[select_factor][Fw[select_factor].index(select_item) + 1]
            _pt = solution_evaluation(_St, item2obj, Tmax, CL, _lambda=la, risk_averse=ra)
            c_ = solution_cost(_St, item2obj)
            Eval_times += 1
            # 如果满足约束条件，则找到初始可行解
            if _pt >= CL:
                break
        else:
            available_S[select_factor] = -1
            # 如果所有因子都已尝试且无解，则重新初始化解
            if (available_S == stopping_condition).all():
                print("Warning: 没有找到可行解, 初始解设为每个class下最小weight的item!")
                _St = solution_initialization(Fw, param, -1)
                break
    # 返回初始可行解及其相关信息
    init_feasible_Solution = _St
    init_obj_cost = solution_cost(_St, item2obj)
    init_p = _pt
    return init_feasible_Solution, init_obj_cost, init_p, Eval_times

# 局部搜索主函数
def localsearch(Fw, Fu, Fv, item2obj, Tmax, CL, param, maxiter, la, ra):
    # 获取初始可行解及相关信息
    _St, _ct, _pt, Eval_times = Construct_Procedure(Fw, Fu, item2obj, CL, Tmax, param, la, ra)
    S_opt = np.copy(_St)
    c_opt = _ct
    _p = _pt
    t = 0
    while t <= maxiter:
        ex_factor = []
        ex_item = [item for item in _St]
        # 进行解的退化操作
        _ct, _pt, _St, eva = Degrade_(_St, _pt, Fv, item2obj, Tmax, CL, param, ex_factor, ex_item, la, ra)
        Eval_times += eva
        # 进行局部交换搜索
        _ct, _pt, _St, Eval_times = Local_Swap_Search(_St, _pt, Fv, item2obj, Tmax, CL, param, Eval_times, la, ra)
        if _ct < c_opt:
            S_opt = np.copy(_St)
            c_opt = _ct
            _p = _pt
        t += 1
    # 进行进一步的交换搜索
    c_opt, _p, S_opt, Eval_times = Further_Swap_Search(S_opt, _p, Fv, item2obj, Tmax, CL, param, Eval_times, la, ra)
    Optimal_Solution = S_opt
    Optimal_cost = c_opt
    Optimal_p = _p
    return Optimal_Solution, Optimal_cost, Optimal_p, Eval_times

# 局部交换搜索函数，尝试在解的局部进行交换操作以改进解
def Local_Swap_Search(Solution, p, Fv, item2obj, Tmax, CL, param, Eval_times, la, ra):
    factor_list = [i for i in range(int(param[0]))]
    _St, _S = np.copy(Solution), np.copy(Solution)
    _p = p
    random.shuffle(factor_list)
    for factor_id in factor_list:
        select_item = _St[factor_id]
        index_ = Fv[factor_id].index(select_item)
        # 尝试在因子内与前面的物品进行交换
        for item_id in Fv[factor_id][:index_][::-1]:
            _St[factor_id] = item_id
            _pt = solution_evaluation(_St, item2obj, Tmax, CL, _lambda=la, risk_averse=ra)
            Eval_times += 1
            if _pt >= CL:
                _S = np.copy(_St)
                _p = _pt
                _c = solution_cost(_S, item2obj)
                break
        _St = np.copy(_S)
    feasible_Solution = _S
    obj_cost = solution_cost(_S, item2obj)
    p = _p
    return obj_cost, p, feasible_Solution, Eval_times

# 解的退化操作函数，尝试替换解中的物品以寻找更好的解
def Degrade_(Solution, _pp, Fw, item2obj, Tmax, CL, param, ex_factor, ex_item, la, ra):
    _St = np.copy(Solution)
    Eval_times = 0
    # 选择一个未在禁忌列表中的因子
    factor_id = choice([i for i in range(int(param[0])) if i not in ex_factor])
    factor_item_ex = [_St[factor_id]]
    # 替换该因子的物品
    _St[factor_id] = choice([item for item in Fw[factor_id] if item not in ex_item])
    factor_item_ex.append(_St[factor_id])  # 更新当前因子的禁忌集
    _pt = solution_evaluation(_St, item2obj, Tmax, CL, _lambda=la, risk_averse=ra)
    Eval_times += 1
    while _pt < CL:
        if len(factor_item_ex) < len(Fw[factor_id]):
            _St[factor_id] = choice([item for item in Fw[factor_id] if item not in factor_item_ex])
            factor_item_ex.append(_St[factor_id])  # 更新当前因子的禁忌集
            _pt = solution_evaluation(_St, item2obj, Tmax, CL, _lambda=la, risk_averse=ra)
            Eval_times += 1
        elif len(ex_factor) < int(param[0]) - 1:
            ex_factor.append(factor_id)
            # 递归进行解的退化操作
            _, _pt, _St, eval = Degrade_(Solution, _pp, Fw, item2obj, Tmax, CL, param, ex_factor, ex_item, la, ra)
            Eval_times = eval
        else:
            _pt = _pp
            return solution_cost(Solution, item2obj), _pt, Solution, Eval_times
    return solution_cost(_St, item2obj), _pt, _St, Eval_times

# 进一步交换搜索函数，在解的不同因子之间进行交换操作以寻找更优解
def Further_Swap_Search(Solution, p, Fv, item2obj, Tmax, CL, param, Eval_times, la, ra):
    _St = np.copy(Solution)
    _c = solution_cost(_St, item2obj)
    _p = p
    factor_list = [i for i in range(int(param[0]))]
    random.shuffle(factor_list)
    for i in range(int(param[0]) - 1):
        factor_id1 = factor_list[i]
        for j in range(i + 1, int(param[0])):
            factor_id2 = factor_list[j]
            solution_group = []
            for item_id1 in Fv[factor_id1]:
                for item_id2 in Fv[factor_id2]:
                    S_temp = np.copy(_St)
                    S_temp[factor_id1], S_temp[factor_id2] = item_id1, item_id2
                    c_st = solution_cost(S_temp, item2obj)
                    if c_st < _c:
                        heapq.heappush(solution_group, list([c_st, S_temp]))
            while solution_group:
                temp = heapq.heappop(solution_group)
                _pt = solution_evaluation(temp[1], item2obj, Tmax, CL, _lambda=la, risk_averse=ra)
                Eval_times += 1
                if _pt >= CL:
                    _St = np.copy(temp[1])
                    _p = _pt
                    _c = temp[0]
                    break
    feasible_Solution = np.copy(_St)
    obj_cost = solution_cost(_St, item2obj)
    p = _p
    return obj_cost, p, feasible_Solution, Eval_times