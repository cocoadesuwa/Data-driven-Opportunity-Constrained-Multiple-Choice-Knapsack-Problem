import re
import math
import copy
import time
import random
import numpy as np
from scipy.stats import norm
from func_Dyer_Zemel import dp
from func_localsearch import localsearch
from func_Genetic import GeneticAlgorithm
from item_operation import Get_item, max_var
from solution_operation import solution_cost, solution_evaluation

# 求解风险规避多选择背包问题（RAMCKP）的函数
def solve_ramckp(ps, pc, es, evastop, maxiter, param, fn, CL, lambda_itera, Tmax_itera, Tmax, alg):
    # 获取物品相关信息，包括价值、索引映射、物品到目标的映射、重量相关函数等
    Value, f2i, item2obj, Fw, Fu, Fv = Get_item(param, lambda_itera, fn)
    risk_averse = True
    # 根据指定算法进行求解
    if alg == 'LS':
        # 使用局部搜索算法求解
        solu, _, p, et = localsearch(Fw, Fu, Fv, item2obj, Tmax_itera, CL, param, maxiter, lambda_itera, risk_averse)
    elif alg == 'GA':
        # 使用遗传算法求解
        solu, _, p, et = GeneticAlgorithm(ps, pc, es, evastop, Fw, Fv, Tmax_itera, item2obj, CL, param, lambda_itera, risk_averse)
    elif alg == 'LS-GA':
        # 使用结合局部搜索的遗传算法求解
        solu, _, p, et = GeneticAlgorithm(ps, pc, es, evastop, Fw, Fv, Tmax_itera, item2obj, CL, param, lambda_itera, risk_averse, localsearch_sign=1)
    else:
        # 使用动态规划算法求解
        solu = dp(Value, f2i, lambda_itera, Tmax_itera)
        et = 0
    # 评估解的质量
    p = solution_evaluation(solu, item2obj, Tmax, CL)
    return solu, p, et, item2obj, f2i

# 求解机会约束多选择背包问题（CCMCKP）的主函数
def CCMCKP_main(ps, pc, es, evastop, mi, Tmax, CL, param, algo, fn):
    # 初始化一些参数
    _epsilon = 10 ** (-5)
    lambda_itera = 0
    Tmax_itera = Tmax
    # 计算标准正态分布的分位数，用于机会约束转换
    C = norm.ppf(CL)
    eval_times = 0
    et = 0
    solve_ra_times = 0
    start_time = time.time()
    # 首先求解初始的RAMCKP问题
    solu, p, et, item2obj, f2i = solve_ramckp(ps, pc, es, evastop, mi, param, fn, CL, lambda_itera, Tmax_itera, Tmax, algo)
    # 记录评估次数和求解RAMCKP的次数
    eval_times += et
    solve_ra_times += 1
    feasible_solution_set = []
    # 如果初始解可行，则结束搜索
    if p >= 0:
        print("\nThe initial solution is feasible, thus the search process has finished.")
        endtime = time.time() - start_time
        optimal_obj = solution_cost(solu, item2obj)
        optimal_solution = solu
        # 进一步评估解的置信水平
        confidencelevel = solution_evaluation(solu, item2obj, Tmax, CL, MonteCarlo=1 * 10 ** 7)
        return optimal_solution, optimal_obj, confidencelevel[1], endtime, eval_times, solve_ra_times
    # 如果初始解不可行，则进入迭代求解过程
    while p < 0:
        _sigma_2 = 0
        # 计算当前解的方差总和
        for j in range(len(f2i)):
            _sigma_2 += item2obj[solu[j]].variance
        _sigma = math.sqrt(_sigma_2)
        # 更新风险规避参数lambda_itera
        lambda_itera = C / _sigma
        # 再次求解RAMCKP问题
        solu, p, et, item2obj, f2i = solve_ramckp(ps, pc, es, evastop, mi, param, fn, CL, lambda_itera, Tmax_itera, Tmax, algo)
        solve_ra_times += 1
        # 如果解可行，则添加到可行解集合中
        if p >= 0:
            feasible_solution_set.append(solu)
        eval_times += et
    # 计算一些用于后续迭代的关键参数，如点a和点b的坐标
    point_a = [C ** 2 / lambda_itera ** 2, Tmax_itera - C ** 2 / lambda_itera]
    point_b = [maximum_total_variance, Tmax_itera - C * math.sqrt(maximum_total_variance)]
    x_a, y_a = point_a[0], point_a[1]
    x_b, y_b = point_b[0], point_b[1]
    # 计算直线的斜率lambda_ab和截距T_ab
    lambda_ab = -(y_b - y_a) / (x_b - x_a)
    T_ab = -lambda_ab * (-x_a) + y_a
    LAMBDA_set = [lambda_ab]
    T_set = [T_ab]
    point_set = [[point_a, point_b]]
    LAMBDA_set_tem = []
    T_set_tem = []
    point_set_tem = []
    iteration_times = 0
    # 进入迭代搜索可行解空间的循环
    while len(LAMBDA_set)!= 0:
        iteration_times += 1
        for i in range(len(LAMBDA_set)):
            lambda_itera = LAMBDA_set[i]
            Tmax_itera = T_set[i]
            # 继续求解RAMCKP问题
            solu, p, et, item2obj, f2i = solve_ramckp(ps, pc, es, evastop, mi, param, fn, CL, lambda_itera, Tmax_itera, Tmax, algo)
            eval_times += et
            solve_ra_times += 1
            # 如果解可行且不在可行解集合中，则添加到可行解集合
            if p >= 0:
                if any(np.array_equal(solu, arr) for arr in feasible_solution_set):
                    feasible_solution_set.append(solu)
            else:
                _sigma_2 = 0
                _mu = 0
                point_1 = point_set[i][0]
                point_2 = point_set[i][1]
                # 计算当前解的方差和均值
                for j in range(len(f2i)):
                    _sigma_2 += item2obj[solu[j]].variance
                    _mu += item2obj[solu[j]].mean
                point_tem = [_sigma_2, _mu]
                # 计算新的lambda和T值，用于更新搜索空间
                lambda_1 = -((point_tem[1] - point_1[1]) / (point_tem[0] - point_1[0]) - _epsilon)
                T_1 = -lambda_1 * (-point_1[0]) + point_1[1]
                lambda_2 = -((point_tem[1] - point_2[1]) / (point_tem[0] - point_2[0]) + _epsilon)
                T_2 = -lambda_2 * (-point_2[0]) + point_2[1]
                LAMBDA_set_tem.append(lambda_1)
                LAMBDA_set_tem.append(lambda_2)
                T_set_tem.append(T_1)
                T_set_tem.append(T_2)
                point_set_tem.append([point_1, point_tem])
                point_set_tem.append([point_tem, point_2])
        # 更新搜索空间相关的集合
        LAMBDA_set = copy.deepcopy(LAMBDA_set_tem)
        T_set = copy.deepcopy(T_set_tem)
        point_set = copy.deepcopy(point_set_tem)
        LAMBDA_set_tem = []
        T_set_tem = []
        point_set_tem = []
    # 计算可行解集合中每个解的目标值
    obj_list = [solution_cost(s, item2obj) for s in feasible_solution_set]
    if not obj_list:
        return None, [], time.time() - start_time
    endtime = time.time() - start_time
    # 找到最优目标值和对应的最优解
    optimal_obj = min(obj_list)
    optimal_solution = feasible_solution_set[obj_list.index(optimal_obj)]
    # 评估最优解的置信水平
    confidencelevel = solution_evaluation(optimal_solution, item2obj, Tmax, CL, MonteCarlo=1 * 10 ** 7)
    return optimal_solution, optimal_obj, confidencelevel[1], endtime, eval_times, solve_ra_times

if __name__ == '__main__':
    # 设置随机种子，确保实验可重复性
    se = random.seed(233)
    folder_name = 'CCMCKPtoRAMCKP/benchmark/instance_5_5_'
    # 从文件夹名称中提取参数
    param = re.findall(r'\d+', folder_name)
    CL = 0.99
    Tmax = 7629.6
    algorithm = ["LS", "DP", "GA", "LS-GA"]
    maxiter_LS = 100
    ps = 500
    pc = 0.6
    es = 0.6
    evastop = 500
    Elitesize = int(ps * es)
    # 使用局部搜索算法求解CCMCKP并输出结果
    optimal_solution, optimal_obj, confilevel, runtime, eval_times, solve_ra_times = CCMCKP_main(ps, pc, Elitesize, evastop, maxiter_LS, Tmax, CL, param, algorithm[0], folder_name)
    print("\nLocal search result:", optimal_solution, "Objective value:", optimal_obj, "Runtime:", runtime, "Confidence level:", confilevel, "Evaluation times:", eval_times, "RA times:", solve_ra_times)
    # 使用遗传算法求解CCMCKP并输出结果
    optimal_solution, optimal_obj, confilevel, runtime, eval_times, solve_ra_times = CCMCKP_main(ps, pc, Elitesize, evastop, maxiter_LS, Tmax, CL, param, algorithm[2], folder_name)
    print("\nGenetic algorithm result:", optimal_solution, "Objective value:", optimal_obj, "Runtime:", runtime, "Confidence level:", confilevel, "Evaluation times:", eval_times, "RA times:", solve_ra_times)
    # 使用结合局部搜索的遗传算法求解CCMCKP并输出结果
    optimal_solution, optimal_obj, confilevel, runtime, eval_times, solve_ra_times = CCMCKP_main(ps, pc, Elitesize, evastop, maxiter_LS, Tmax, CL, param, algorithm[3], folder_name)
    print("\nLS based Genetic algorithm result:", optimal_solution, "Objective value:", optimal_obj, "Runtime:", runtime, "Confidence level:", confilevel, "Evaluation times:", eval_times, "RA times:", solve_ra_times)
    # 使用动态规划算法求解CCMCKP并输出结果
    optimal_solution, optimal_obj, confilevel, runtime, _, solve_ra_times = CCMCKP_main(ps, pc, es, evastop, maxiter_LS, Tmax, CL, param, algorithm[1], folder_name)
    print("\nDynamic programming result:", optimal_solution, "Objective value:", optimal_obj, "Runtime:", runtime, "Confidence level:", confilevel, "RA times:", solve_ra_times)