import sys
sys.path.append('.')
from item_operation import Get_weight
import copy

# 定义 Goods 类，用于表示物品，包含行、列、价值和重量属性
class Good():
    def __init__(self, row, col, p, w):
        self.row = row
        self.col = col
        self.p = p
        self.w = w

    # 定义对象的字符串表示形式，方便调试和输出
    def __repr__(self):
        return str((self.w, self.p))

# 过滤被线性规划支配的物品的函数
def goods_filter_LP_dominated(goods, exacting=True):
    # 对每个物品组按照重量进行升序排序
    [goods[i].sort(key=lambda n: n.w, reverse=False) for i in range(len(goods))]
    # 初始化一个新的列表，每个子列表包含每个物品组的第一个物品
    goods1 = [[goods[i][0]] for i in range(len(goods))]
    for i in range(len(goods)):
        # 记录当前物品的价值和重量
        p, w = goods1[i][0].p, goods1[i][0].w
        for j in range(1, len(goods[i])):
            # 如果新物品重量相同但价值更高，则替换当前物品
            if goods[i][j].w == w and goods[i][j].p > p:
                goods1[i][-1] = goods[i][j]
                p = goods[i][j].p
            # 如果新物品重量更大且价值更高，则添加到列表中
            elif goods[i][j].w > w and goods[i][j].p > p:
                goods1[i].append(goods[i][j])
                p, w = goods[i][j].p, goods[i][j].w
    if exacting:
        goods2 = [[goods1[i][0]] for i in range(len(goods1))]
        for i in range(len(goods1)):
            j = 0
            while j < len(goods1[i]) - 1:
                # 计算相邻物品的斜率，用于进一步筛选
                slopes = [[k, (goods1[i][k].p - goods1[i][j].p) / (goods1[i][k].w - goods1[i][j].w)] for k in range(j + 1, len(goods1[i]))]
                slopes.sort(key=lambda x: x[1], reverse=True)
                j = slopes[0][0]
                goods2[i].append(goods1[i][j])
        goods1 = goods2
    return goods1

# 动态规划求解函数
def Dynamic(W, P, n2f, c):
    # 根据给定的重量和价值矩阵创建物品列表
    goods = [[Good(i, j, P[i][j], W[i][j]) for j in range(len(W[i]))] for i in range(len(W)) if len(W[i]) > 0]
    G = copy.deepcopy(goods)
    # 过滤物品列表
    goods = goods_filter_LP_dominated(G, exacting=False)
    # 定义组合类，用于表示一组物品的组合信息
    class Combination():
        def __init__(self, P, W, L):
            self.P = P
            self.W = W
            self.L = L

        # 定义组合对象的字符串表示形式
        def __repr__(self):
            return str((self.W, self.P))

    # 初始化动态规划的基本情况，以第一个物品组的物品为基础
    C = {goods[0][j].w: Combination(goods[0][j].p, goods[0][j].w, [goods[0][j]]) for j in range(len(goods[0]))}
    for i in range(1, len(goods)):
        C_next = {}
        for j in range(len(goods[i])):
            for k, v in C.items():
                # 如果当前物品与组合的重量超过容量限制，则跳过
                if goods[i][j].w + k > c:
                    continue
                # 如果新组合的价值更高，则更新组合信息
                if (goods[i][j].w + k not in C_next) or (goods[i][j].w + k in C_next and goods[i][j].p + v.P > C_next[goods[i][j].w + k].P):
                    C_next[goods[i][j].w + k] = Combination(goods[i][j].p + v.P, goods[i][j].w + k, v.L + [goods[i][j]])
        C = C_next
    if len(C)!= 0:
        res = list(C.values())
        res.sort(key=lambda x: x.P, reverse=True)
        res_choose = res[0].L
        obj_value = res[0].P
        weight = res[0].W
        solution = []
        for i in range(len(goods)):
            column = res_choose[i].col
            ind_ = n2f[i][column].id
            solution.append(ind_)
        return solution
    else:
        return None

# 最终的动态规划求解接口函数，调用其他函数完成求解过程
def dp(Value, f2i, lambda_itera, Tmax_itera):
    W = Get_weight(f2i, lambda_itera)
    return Dynamic(W, Value, f2i, Tmax_itera)

if __name__ == '__main__':
    Tmax = 14
    CL = 0.9