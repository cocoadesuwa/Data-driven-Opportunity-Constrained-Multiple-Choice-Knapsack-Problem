import math
import numpy as np
import my_file
import item

# 计算每个因子中物品方差最大值之和的函数
def max_var(factors_to_items):
    factor_num = len(factors_to_items)
    factor_id_list = [i for i in range(factor_num)]
    max_var_list = []
    # 遍历每个因子
    for factor_id in factor_id_list:
        cur_factors = factors_to_items[factor_id]
        # 找到当前因子中物品方差的最大值并添加到列表
        max_var_list.append(max([f.variance for f in cur_factors]))
    # 返回所有因子中方差最大值之和
    return sum(max_var_list)

# 获取物品相关信息的函数
def Get_item(param, _lambda, data_folder):
    factor_num, item_num = int(param[0]), int(param[1])
    item_num_sum = factor_num * item_num
    factor_id_list = [i for i in range(factor_num)]
    item_id_list = [i for i in range(item_num_sum)]
    # 从文件中加载因子到物品 ID 的映射关系
    factor_to_item_id = my_file.load_pkl_in_repo(data_folder, 'factor_to_item.pkl')
    # 加载物品成本列表
    cost_list = np.loadtxt(my_file.real_path_of(data_folder, 'cost.txt'))
    max_cost = np.max(cost_list)
    item2obj = []
    # 遍历每个物品 ID
    for item_id in item_id_list:
        cost_ = cost_list[item_id]
        value_ = max_cost - cost_list[item_id]
        filename_ = f'{item_id}_dist.txt'
        with open(my_file.real_path_of(data_folder, filename_), 'r') as f:
            data = f.readlines()
        _mean = float(data[1].strip().split()[1])
        _variance = float(data[2].strip().split()[1])
        # 创建物品对象并添加到列表
        cur_item = item(item_id, cost_, value_, _mean, _variance)
        item2obj.append(cur_item)
    factor_to_items = {factor_id: [] for factor_id in factor_id_list}
    # 构建因子到物品对象的映射关系
    for factor_id in factor_id_list:
        cur_item_id_list = factor_to_item_id[factor_id]
        for cur_item_id in cur_item_id_list:
            factor_to_items[factor_id].append(item2obj[cur_item_id])
    factor_resort_utility = {factor_id: [] for factor_id in factor_id_list}
    factor_resort_weight = {factor_id: [] for factor_id in factor_id_list}
    factor_resort_value = {factor_id: [] for factor_id in factor_id_list}
    # 对每个因子中的物品进行处理
    for factor_id in factor_id_list:
        cur_items = factor_to_items[factor_id]
        cur_items_mean_list = [f.mean for f in cur_items]
        cur_items_std_list = [math.sqrt(f.variance) for f in cur_items]
        cur_items_value_list = [f.value for f in cur_items]
        # 根据给定的 lambda 调整物品的标准差
        cur_items_std_list[:] = [x * _lambda for x in cur_items_std_list]
        weight_items_list = [cur_items_mean_list[i] + cur_items_std_list[i] for i in range(len(cur_items))]
        utility_items_list = [cur_items_value_list[i] / weight_items_list[i] for i in range(len(cur_items))]
        for i in range(len(weight_items_list)):
            # 设置物品的重量和效用值
            cur_items[i].set_weight(weight_items_list[i])
            cur_items[i].set_utility(utility_items_list[i])
        # 根据重量、效用和价值对物品进行排序
        cand_indices_weight = np.argsort(weight_items_list)[::-1]  
        cand_indices_utility = np.argsort(utility_items_list)[::-1]  
        cand_indices_value = np.argsort(cur_items_value_list)[::-1]  
        for _idx in cand_indices_weight:
            factor_resort_weight[factor_id].append(cur_items[_idx].id)
        for _idx in cand_indices_utility:
            factor_resort_utility[factor_id].append(cur_items[_idx].id)
        for _idx in cand_indices_value:
            factor_resort_value[factor_id].append(cur_items[_idx].id)
    value_list = []
    # 构建每个因子中物品价值的列表
    for factor_id in factor_id_list:
        cur_items = factor_to_items[factor_id]
        cur_items_value_list = [f.value for f in cur_items]
        value_list.append(cur_items_value_list)
    return value_list, factor_to_items, item2obj, factor_resort_weight, factor_resort_utility, factor_resort_value

# 获取每个因子中物品重量列表的函数
def Get_weight(factor_to_items, _lambda):
    factor_num = len(factor_to_items)
    factor_id_list = [i for i in range(factor_num)]
    weight_list = []
    # 遍历每个因子
    for factor_id in factor_id_list:
        cur_items = factor_to_items[factor_id]
        cur_items_mean_list = [item.mean for item in cur_items]
        cur_items_var_list = [item.variance for item in cur_items]
        lambda_va = [x * _lambda for x in cur_items_var_list]
        weight_items_list = [cur_items_mean_list[i] + lambda_va[i] for i in range(len(cur_items))]
        weight_list.append(weight_items_list)
    return weight_list