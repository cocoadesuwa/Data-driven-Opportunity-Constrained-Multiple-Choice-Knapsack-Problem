import os
import math
import random
import numpy as np
import my_file
from collections import OrderedDict

# 定义 Benchmark 类，用于生成基准测试数据
class Benchmark:
    # 类的初始化函数，接收因子数量和每个因子的物品数量作为参数
    def __init__(self, factor_num, item_num):
        self.item_num = item_num
        self.factor_num = factor_num
        # 计算物品总数
        self.item_num_sum = self.factor_num * self.item_num
        current_directory = os.path.dirname(os.path.abspath(__file__))
        # 构建保存基准测试数据的文件夹路径
        self.save_folder = os.path.join(current_directory, f'benchmark/instance_{factor_num}_{item_num}_')
        my_file.create_folder(self.save_folder)

    # 保存属性的私有方法，将分布类型、均值、方差等属性保存到文件中
    def _save_attributes(self, factor_id, distribution, mu_, variance_, select=None):
        attr_dict = OrderedDict()
        attr_dict['dist_type'] = distribution
        attr_dict['para_mean'] = mu_
        attr_dict['param_variance'] = variance_
        if select is not None:
            attr_dict['select'] = select
        filename_ = f'{factor_id}_dist.txt'
        # 打开文件并写入属性信息
        with open(my_file.real_path_of(self.save_folder, filename_), 'w') as f:
            for k, v in attr_dict.items():
                f.write(f'{k} {v}\n')
        print(f"Factor ID {factor_id}, Distribution {distribution}, Mean {mu_}, Variance {variance_ }, Success!")

    # 生成高斯分布数据的方法，根据给定的均值和方差范围生成随机的高斯分布参数并保存
    def generate_Gaussian(self, item_id, mean_, var_):
        # 对均值进行一定范围内的随机调整
        mu_ = mean_ * (1 + 1.2 * np.random.rand() - 0.6)
        # 对方差进行一定范围内的随机调整
        variance_ = var_ * (1 + 1.8 * np.random.rand() - 0.9)
        self._save_attributes(item_id, 'Gaussian', mu_, variance_)

    # 生成基准测试数据的主要方法
    def generate_benchmark(self):
        # 遍历所有物品，为每个物品生成高斯分布数据
        for item_id in range(self.item_num_sum):
            self.generate_Gaussian(item_id, 2000, 12000)

    # 生成因子与物品关联关系的方法
    def generate_factor_link(self):
        # 生成因子 ID 列表和物品 ID 列表
        factor_id_list = [i for i in range(self.factor_num)]
        item_id_list = [i for i in range(self.item_num_sum)]
        factor_to_item = {}
        # 构建因子到物品的映射关系
        for factor_id in factor_id_list:
            res_list = []
            for item_id in item_id_list:
                if item_id % self.factor_num == factor_id:
                    res_list.append(item_id)
            factor_to_item[factor_id] = res_list
        # 打印因子到物品的映射关系
        for k in factor_to_item:
            print(f'{k}: {factor_to_item[k]}')
        my_file.save_pkl_in_repo(factor_to_item, self.save_folder, 'factor_to_item.pkl')
        weight_items_list = []
        # 计算每个物品的权重并构建权重列表
        for item_id in item_id_list:
            filename_ = f'{item_id}_dist.txt'
            with open(my_file.real_path_of(self.save_folder, filename_), 'r') as f:
                data = f.readlines()
            items_mean = float(data[1].strip().split()[1])
            items_variance = float(data[2].strip().split()[1])
            weight_items_list.append(items_mean + math.sqrt(items_variance))
        # 生成物品成本列表
        item_cost_list = np.random.random(size=self.item_num_sum) * 90 + 50
        np.savetxt(my_file.real_path_of(self.save_folder, 'cost.txt'), item_cost_list)

if __name__ == '__main__':
    # 设置随机种子，确保数据生成的可重复性
    random.seed(827)
    Benchmark_1 = Benchmark(factor_num=100, item_num=50)
    Benchmark_1.generate_benchmark()
    Benchmark_1.generate_factor_link()