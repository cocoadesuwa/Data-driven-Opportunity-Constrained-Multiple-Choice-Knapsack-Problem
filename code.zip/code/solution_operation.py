import math
import numpy as np
from scipy.stats import norm

# 评估解的函数，判断解是否满足约束条件或计算相关指标
def solution_evaluation(solution, item2obj, T, confidence_level, _lambda=0, risk_averse=None, MonteCarlo=None):
    item_list = []
    # 将解中的物品信息添加到列表中
    for item_id in solution:
        item_list.append(item2obj[item_id])

    # 根据风险规避策略进行不同的计算
    if risk_averse is None:
        # 计算考虑正态分布的总和，包括均值和标准差的影响
        s = sum([f.mean for f in item_list]) + norm.ppf(confidence_level) * math.sqrt(sum([f.variance for f in item_list]))
        if s <= T:
            result_sign = 1
        else:
            # 计算不满足约束的比例
            result_sign = (T - s) / T
    else:
        # 计算考虑风险规避参数的总和
        s = sum([f.mean for f in item_list]) + _lambda * sum([f.variance for f in item_list])
        if s <= T:
            result_sign = 1
        else:
            result_sign = (T - s) / T

    # 如果需要进行蒙特卡洛模拟评估，则执行以下操作
    if MonteCarlo is not None:
        estimated_cl = MC_solution_evaluation(item_list, T, 1000, int(MonteCarlo / 1000))
        return result_sign, estimated_cl
    else:
        return result_sign

# 生成正态分布随机样本的函数
def Norm(sample_size, mu_, variance_):
    return np.random.normal(mu_, np.sqrt(variance_), sample_size)

# 蒙特卡洛模拟评估解的函数
def MC_solution_evaluation(item_list, Tmax, group_num, small_sample_size):
    total_ = 0
    # 进行多次模拟
    for _ in range(group_num):
        # 计算每次模拟的样本总和
        sum_samples = np.sum(Norm(small_sample_size, item.mean, item.variance) for item in item_list)
        # 统计满足约束条件的样本数量
        total_ += len(np.where(sum_samples <= Tmax)[0])
    # 计算满足约束条件的比例
    return total_ / (group_num * small_sample_size)

# 初始化解的函数，根据给定的因子资源和顺序生成初始解
def solution_initialization(factor_resort, param, order):
    factor_id_list = [i for i in range(int(param[0]))]
    Init_solution = np.zeros(len(factor_id_list), dtype=int)
    for factor_id in factor_id_list:
        Init_solution[factor_id] = factor_resort[factor_id][order]
    return Init_solution

# 计算解的成本函数，累加解中每个物品的成本
def solution_cost(solution, item2obj):
    total_cost = 0
    for item_id in solution:
        item = item2obj[item_id]
        total_cost += item.cost
    return total_cost